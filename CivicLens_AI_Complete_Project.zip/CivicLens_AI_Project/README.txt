CIVICLENS AI — COMPLETE HACKATHON PROJECT
=========================================

PROJECT CONTENTS
----------------
index.html
    Main application structure.

style.css
    Application design and responsive layout.

script.js
    Complaint submission, image preview, demo AI analysis,
    tracking, admin status updates, search and browser storage.

CivicLens_AI_Hackathon_Presentation_6_Slides.pptx
    Six-slide presentation for a three-member team.

3_Member_Presentation_Script.txt
    Speaking script divided between three presenters.

HOW TO RUN
----------
1. Extract the ZIP file.
2. Open the CivicLens_AI_Project folder in Visual Studio Code.
3. Make sure index.html, style.css and script.js are in the same folder.
4. Open index.html in Chrome or Edge.
   Recommended: install the VS Code "Live Server" extension,
   right-click index.html and choose "Open with Live Server".
5. Test the Citizen App and Admin Dashboard.

DEMO FLOW
---------
1. Open Citizen App.
2. Select a category such as Road / Pothole.
3. Enter a location and description.
4. Optionally upload a photograph.
5. Click "Analyze with CivicLens AI".
6. Click "Submit report".
7. Open Admin Dashboard.
8. Change the new complaint status from Open to In Progress,
   then to Resolved.
9. Observe the dashboard counters update.

IMPORTANT TECHNICAL NOTES
-------------------------
- This is a front-end hackathon prototype.
- The AI analysis is a rule-based demonstration, not a trained
  computer-vision model.
- Reports are stored in the browser using localStorage.
- Browser-local data is not automatically shared between devices.
- Real GPS, cloud database, authentication, push notifications,
  trained image recognition and government integration are not
  included in this prototype; they are future development items.
- Do not present simulated AI or local browser storage as a
  production AI/cloud service.

TEAM PRESENTATION
-----------------
Member 1: Slides 1–2 — Introduction and problem statement.
Member 2: Slides 3–4 — Solution and workflow.
Member 3: Slides 5–6 — Technology, impact and conclusion.
